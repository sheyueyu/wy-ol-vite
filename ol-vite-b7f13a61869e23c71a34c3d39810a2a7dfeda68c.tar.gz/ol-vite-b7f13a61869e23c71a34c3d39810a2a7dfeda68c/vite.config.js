export default {
  build: {
    sourcemap: true,
  }
}
